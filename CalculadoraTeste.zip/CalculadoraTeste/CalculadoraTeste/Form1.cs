﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraTeste
{
    public partial class FrmCalc : Form
    {
        public FrmCalc()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            float vlrN1 = float.Parse(txtN1.Text);
            float vlrN2 = float.Parse(txtN2.Text);
            float resultado;

            //soma
            resultado = vlrN1 + vlrN2;
            MessageBox.Show("A soma de Num1 e Num2 é = " + resultado);
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            float vlrN1 = float.Parse(txtN1.Text);
            float vlrN2 = float.Parse(txtN2.Text);
            float resultado;

            //subtraçao
            resultado = vlrN1 - vlrN2;
            MessageBox.Show("A subtração de Num1 e Num2 é = " + resultado);
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            float vlrN1 = float.Parse(txtN1.Text);
            float vlrN2 = float.Parse(txtN2.Text);
            float resultado;

            //Multiplicação
            resultado = vlrN1 * vlrN2;
            MessageBox.Show("A multiplicação de Num1 e Num2 é = " + resultado);

        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            float vlrN1 = float.Parse(txtN1.Text);
            float vlrN2 = float.Parse(txtN2.Text);
            float resultado;

            //divisao
            resultado = vlrN1 / vlrN2;
            MessageBox.Show("A divisão de Num1 e Num2 é = " + resultado);

        }
    }
}
